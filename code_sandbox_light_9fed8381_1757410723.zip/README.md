# Romantic Questions Website 💖

A beautiful, interactive romantic website designed to ask your girlfriend special questions with a magical user experience featuring floating hearts, soft pink gradients, and emotional animations.

## 🌟 Features

### Currently Completed Features
- **Interactive Question Flow**: Progressive display of 5 romantic questions
- **Romantic Theme**: Soft pink & red gradient background with floating heart animations
- **Playful NO Button**: When "NO" is clicked, shows a playful message encouraging YES
- **Heart Burst Effects**: Beautiful heart animations when YES is clicked
- **Final Romantic Message**: Special message after all questions are answered YES
- **Confetti Celebration**: Falling heart confetti for the final message
- **Mobile Responsive**: Fully optimized for mobile devices and tablets
- **Modern Typography**: Dancing Script for titles, Poppins for body text
- **Smooth Animations**: CSS animations for all interactions and transitions
- **Keyboard Support**: Y/N keys can be used instead of clicking buttons

### Visual Effects
- **Floating Hearts**: 8 continuously floating hearts in the background
- **Glowing Borders**: Animated gradient borders on question cards
- **Button Hover Effects**: Interactive button animations with ripple effects
- **Shake Animation**: NO button shakes when clicked
- **Pulse Effects**: Title and question text have subtle pulse animations

## 🎯 Interactive Flow

### Questions Asked (in order):
1. "Vle asa ne jalabi? 😘"
2. "Moi aitu website tmr krone design krisu interested jdi yes click kora 💻❤"
3. "Do you love me truly from your heart? ❤"
4. "Moi tmk bht miss kri asu 🥺, tmiu sge muk miss kri asa?"
5. "Tumi Mur lgt gutai life thkiba ne?? 💍"

### User Experience:
- **YES Button**: Advances to next question with heart burst animation
- **NO Button**: Shows playful alert "Oh no! 😢 Try again, you know the answer is YES 💕"
- **Final Message**: After all YES answers, displays romantic message with confetti
- **Back to Start**: Button to restart the entire experience

## 📁 Project Structure

```
romantic-website/
├── index.html          # Main HTML file with semantic structure
├── css/
│   └── style.css       # Complete styling with animations and responsive design
├── js/
│   └── script.js       # Interactive functionality and animations
└── README.md           # Project documentation
```

## 🎨 Design Features

### Color Palette
- **Primary**: Pink gradients (#ff9a9e, #fecfef, #ff69b4)
- **Secondary**: Deep pink (#d63384, #e91e63)
- **Accents**: Hot pink (#ff1493), crimson (#dc143c)

### Typography
- **Headings**: Dancing Script (cursive, romantic)
- **Body Text**: Poppins (modern, clean)
- **Font Weights**: 300-700 for hierarchy

### Animations
- **floatHeart**: Continuous floating hearts background
- **heartBurst**: Dynamic heart burst on YES clicks
- **confettiFall**: Celebration confetti hearts
- **fadeInScale**: Smooth entrance animations
- **pulse**: Gentle pulsing effects
- **shake**: Playful NO button shake

## 📱 Mobile Responsiveness

### Breakpoints
- **Desktop**: Full experience with large fonts and animations
- **Tablet (768px)**: Adjusted spacing and font sizes
- **Mobile (480px)**: Stacked buttons, optimized touch targets

### Mobile Optimizations
- Touch-friendly button sizes (minimum 44px)
- Readable font sizes on small screens
- Proper viewport meta tag
- Optimized animations for mobile performance

## 🚀 Technical Implementation

### HTML Features
- Semantic HTML5 structure
- Accessibility considerations (proper headings, alt text)
- Meta tags for mobile optimization
- Custom favicon with heart emoji

### CSS Features
- CSS Grid and Flexbox for layouts
- CSS Custom Properties for consistent theming
- Advanced animations with keyframes
- Backdrop filters for modern glass effects
- Media queries for responsive design

### JavaScript Features
- Event-driven architecture
- Dynamic DOM manipulation
- Custom modal creation (instead of browser alerts)
- Keyboard event handling
- Animation timing and cleanup

## 🎭 User Experience Highlights

### Emotional Journey
1. **Anticipation**: Beautiful entrance with floating hearts
2. **Engagement**: Interactive questions with immediate feedback
3. **Playfulness**: Gentle correction for NO answers
4. **Celebration**: Heart bursts for each YES answer
5. **Climax**: Final romantic message with confetti celebration
6. **Replay**: Option to experience again

### Interactive Elements
- **Hover Effects**: All buttons have engaging hover states
- **Visual Feedback**: Immediate animations for all actions
- **Accessibility**: Keyboard navigation support
- **Mobile Touch**: Optimized for touch interactions

## 🔧 Browser Compatibility

- **Modern Browsers**: Chrome, Firefox, Safari, Edge (full support)
- **Mobile Browsers**: iOS Safari, Chrome Mobile (optimized)
- **Features Used**: CSS Grid, Flexbox, backdrop-filter, CSS animations

## 🌐 Deployment

To deploy this romantic website:

1. **Static Hosting**: Upload all files to any static hosting service
2. **CDN**: Uses Google Fonts CDN for typography
3. **No Dependencies**: Pure HTML, CSS, JavaScript (no build process needed)

### Recommended Hosting
- Netlify, Vercel, GitHub Pages, or any static hosting service

## 💝 Customization Options

### Easy Customizations:
- **Questions**: Edit the `questions` array in `script.js`
- **Colors**: Modify CSS custom properties for theme colors
- **Final Message**: Update the message in `index.html`
- **Heart Types**: Change emoji hearts in CSS and JavaScript

### Advanced Customizations:
- Add more questions to the array
- Customize animation durations and effects
- Add sound effects for interactions
- Include photo galleries or videos

## 📝 Performance Notes

- **Lightweight**: Total size < 50KB for fast loading
- **Optimized Animations**: Smooth 60fps animations
- **Mobile Friendly**: Optimized for mobile performance
- **Progressive Enhancement**: Works without JavaScript (basic functionality)

## 💕 Perfect For

- **Romantic Proposals**: Lead up to important questions
- **Anniversary Celebrations**: Interactive romantic experience
- **Valentine's Day**: Special romantic gesture
- **Long Distance Relationships**: Shareable romantic experience
- **Special Occasions**: Birthdays, relationship milestones

---

**Created with love 💖 for that special someone in your life**

*"Thank you for coming into my life. You are my happiness, my reason to smile, and my forever."*
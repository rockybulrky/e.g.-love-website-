// Questions array with cute emojis
const questions = [
    "Vle asa ne jalabi? 😘",
    "Moi aitu website tmr krone design krisu interested jdi yes click kora 💻❤",
    "Do you love me truly from your heart? ❤",
    "Moi tmk bht miss kri asu 🥺, tmiu sge muk miss kri asa?",
    "Tumi Mur lgt gutai life thkiba ne?? 💍"
];

let currentQuestionIndex = 0;

// DOM elements
const questionText = document.getElementById('questionText');
const currentQuestionNumber = document.getElementById('currentQuestion');
const questionContainer = document.getElementById('questionContainer');
const finalMessage = document.getElementById('finalMessage');
const confettiContainer = document.getElementById('confettiContainer');

// Initialize the first question
function initializeQuestions() {
    displayCurrentQuestion();
}

// Display current question
function displayCurrentQuestion() {
    if (currentQuestionIndex < questions.length) {
        questionText.textContent = questions[currentQuestionIndex];
        currentQuestionNumber.textContent = currentQuestionIndex + 1;
        
        // Add entrance animation
        questionText.style.animation = 'none';
        questionText.offsetHeight; // Trigger reflow
        questionText.style.animation = 'questionPulse 2s ease-in-out infinite';
    }
}

// Handle answer (YES/NO button clicks)
function handleAnswer(isYes) {
    if (isYes) {
        handleYesAnswer();
    } else {
        handleNoAnswer();
    }
}

// Handle YES answer
function handleYesAnswer() {
    // Create heart burst effect
    createHeartBurst();
    
    currentQuestionIndex++;
    
    if (currentQuestionIndex < questions.length) {
        // Move to next question with animation
        setTimeout(() => {
            displayCurrentQuestion();
        }, 500);
    } else {
        // All questions answered - show final message
        setTimeout(() => {
            showFinalMessage();
        }, 1000);
    }
}

// Handle NO answer with playful behavior
function handleNoAnswer() {
    // Show playful alert
    showPlayfulAlert();
    
    // Make the NO button run away or shake
    const noBtn = document.getElementById('noBtn');
    noBtn.style.animation = 'shake 0.5s ease-in-out';
    
    // Reset animation after it completes
    setTimeout(() => {
        noBtn.style.animation = '';
    }, 500);
}

// Show playful alert for NO answer
function showPlayfulAlert() {
    // Create custom modal instead of browser alert for better styling
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(15px);
        padding: 30px;
        border-radius: 20px;
        box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        text-align: center;
        z-index: 1000;
        border: 2px solid #ff69b4;
        animation: fadeInScale 0.3s ease-out;
        max-width: 350px;
        width: 90%;
    `;
    
    modal.innerHTML = `
        <div style="font-size: 1.5rem; color: #d63384; margin-bottom: 15px;">Oh no! 😢</div>
        <div style="font-size: 1.1rem; color: #e91e63; margin-bottom: 20px;">Try again, you know the answer is YES 💕</div>
        <button onclick="this.parentElement.remove()" style="
            background: linear-gradient(45deg, #ff69b4, #ff1493);
            color: white;
            border: none;
            padding: 10px 25px;
            border-radius: 25px;
            cursor: pointer;
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.3s ease;
        " onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
            Okay 💖
        </button>
    `;
    
    document.body.appendChild(modal);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        if (modal.parentElement) {
            modal.remove();
        }
    }, 3000);
}

// Show final romantic message
function showFinalMessage() {
    questionContainer.style.display = 'none';
    finalMessage.classList.add('show');
    
    // Create celebration confetti
    createConfettiHearts();
    
    // Add special celebration animation to the container
    setTimeout(() => {
        const container = document.querySelector('.container');
        container.style.animation = 'pulse 2s ease-in-out infinite';
    }, 500);
}

// Create heart burst effect for YES answers
function createHeartBurst() {
    const heartsCount = 8;
    const colors = ['💖', '💕', '💗', '💘', '💝', '❤️'];
    
    for (let i = 0; i < heartsCount; i++) {
        const heart = document.createElement('div');
        heart.textContent = colors[Math.floor(Math.random() * colors.length)];
        heart.style.cssText = `
            position: fixed;
            font-size: 1.5rem;
            pointer-events: none;
            z-index: 1000;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            animation: heartBurst ${0.8 + Math.random() * 0.4}s ease-out forwards;
        `;
        
        // Random direction for burst
        const angle = (i / heartsCount) * 360;
        heart.style.setProperty('--angle', angle + 'deg');
        
        document.body.appendChild(heart);
        
        // Remove heart after animation
        setTimeout(() => {
            heart.remove();
        }, 1200);
    }
}

// Create confetti hearts for final celebration
function createConfettiHearts() {
    const heartsCount = 15;
    const colors = ['💖', '💕', '💗', '💘', '💝', '❤️', '💞', '💓'];
    
    for (let i = 0; i < heartsCount; i++) {
        setTimeout(() => {
            const heart = document.createElement('div');
            heart.textContent = colors[Math.floor(Math.random() * colors.length)];
            heart.className = 'confetti-heart';
            heart.style.left = Math.random() * 100 + '%';
            heart.style.animationDelay = Math.random() * 2 + 's';
            heart.style.animationDuration = (3 + Math.random() * 2) + 's';
            
            confettiContainer.appendChild(heart);
            
            // Remove heart after animation
            setTimeout(() => {
                heart.remove();
            }, 5000);
        }, i * 200);
    }
}

// Restart questions
function restartQuestions() {
    currentQuestionIndex = 0;
    questionContainer.style.display = 'block';
    finalMessage.classList.remove('show');
    confettiContainer.innerHTML = '';
    
    // Reset container animation
    const container = document.querySelector('.container');
    container.style.animation = '';
    
    displayCurrentQuestion();
    
    // Add restart animation
    questionContainer.style.animation = 'fadeInUp 0.5s ease-out';
}

// Add heart burst animation keyframes dynamically
function addHeartBurstAnimation() {
    const style = document.createElement('style');
    style.textContent = `
        @keyframes heartBurst {
            0% {
                transform: translate(-50%, -50%) scale(0) rotate(0deg);
                opacity: 1;
            }
            50% {
                transform: translate(-50%, -50%) translate(${Math.cos(0) * 100}px, ${Math.sin(0) * 100}px) scale(1.2) rotate(180deg);
                opacity: 1;
            }
            100% {
                transform: translate(-50%, -50%) translate(${Math.cos(0) * 150}px, ${Math.sin(0) * 150}px) scale(0.8) rotate(360deg);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
}

// Enhanced heart burst with proper angles
function createHeartBurst() {
    const heartsCount = 12;
    const colors = ['💖', '💕', '💗', '💘', '💝', '❤️'];
    
    for (let i = 0; i < heartsCount; i++) {
        const heart = document.createElement('div');
        heart.textContent = colors[Math.floor(Math.random() * colors.length)];
        
        const angle = (i / heartsCount) * 360;
        const radian = (angle * Math.PI) / 180;
        const distance = 100 + Math.random() * 50;
        const x = Math.cos(radian) * distance;
        const y = Math.sin(radian) * distance;
        
        heart.style.cssText = `
            position: fixed;
            font-size: ${1.2 + Math.random() * 0.8}rem;
            pointer-events: none;
            z-index: 1000;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            animation: heartBurstCustom 1s ease-out forwards;
        `;
        
        // Create custom animation for this heart
        const animationName = `heartBurst${i}`;
        const keyframes = `
            @keyframes ${animationName} {
                0% {
                    transform: translate(-50%, -50%) scale(0) rotate(0deg);
                    opacity: 1;
                }
                20% {
                    transform: translate(-50%, -50%) scale(1.3) rotate(90deg);
                    opacity: 1;
                }
                100% {
                    transform: translate(-50%, -50%) translate(${x}px, ${y}px) scale(0.5) rotate(360deg);
                    opacity: 0;
                }
            }
        `;
        
        // Add keyframes to document
        const style = document.createElement('style');
        style.textContent = keyframes;
        document.head.appendChild(style);
        
        heart.style.animation = `${animationName} 1s ease-out forwards`;
        
        document.body.appendChild(heart);
        
        // Remove heart and style after animation
        setTimeout(() => {
            heart.remove();
            style.remove();
        }, 1200);
    }
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    initializeQuestions();
    
    // Add some interactive hover effects
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-3px) scale(1.05)';
        });
        
        button.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });
});

// Add keyboard support for better accessibility
document.addEventListener('keydown', function(event) {
    if (event.key === 'y' || event.key === 'Y') {
        handleAnswer(true);
    } else if (event.key === 'n' || event.key === 'N') {
        handleAnswer(false);
    }
});